const serverless = require('serverless-http');
const express = require('express');
const app = express();
const bodyParser = require("body-parser");

const loginController = require('./app/controllers/loginController');
const { check } = require('express-validator');

app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/operator-login', [
    check('email').exists().isEmail().not().isEmpty(),
    check('password').exists().not().isEmpty()
], loginController.login);

module.exports.handler = serverless(app);