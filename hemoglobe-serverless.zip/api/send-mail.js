const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const express = require('express');
const app = express();
app.use(bodyParser.json());

module.exports.handler = async (req, res) => {
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'nitish.jaswal@netsolutions.com',
      pass: 'W8>gChmP$'
    }
  });

  var body = JSON.parse(req.body);  
  var msg = "Hello "+ body.to_name + ",\n";
  msg += body.from_name + " has sent you the following message.\n";
  msg += body.message+"\n\n";
  msg += "Thanks\n";
  msg += "Team Hemoglobe\n";
  var mailOptions = {
    from: body.from_email,
    to: body.to_email,
    subject: "Hemoglobe: "+body.from_name+" has sent you the message",
    text: msg
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    
  });

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Email has been sent successfully!'          
      }
  )};
  
};