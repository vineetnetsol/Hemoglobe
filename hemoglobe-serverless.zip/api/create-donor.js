const serverless = require('serverless-http');
const express = require('express')
const app = express();
const bodyParser = require('body-parser');
const { check, body } = require('express-validator');
const {gender, blood_type, boolean, donor_contact_mode, donor_contact_disturbance_time} = require('./app/config/params');
const donorsController = require('./app/controllers/donorsController');

//Parse application/json
app.use(bodyParser.json());

//Create (register) donor
app.post('/donor', [
    check('name').exists().not().isEmpty(), 
    check('dob').exists().isISO8601().toDate(),
    check('gender').exists().isIn(Object.keys(gender)),
    check('blood_group').exists().isIn(blood_type),
    check('disease').exists().isIn(boolean),
    check('city').exists().not().isEmpty(),
    check('state').exists().not().isEmpty(),
    check('email').exists().isEmail(),
    check('phone').exists().not().isEmpty(),
    check('address').exists().not().isEmpty(),
    check('contact_mode.*').exists().isIn(Object.keys(donor_contact_mode)),
    check('contact_directly').exists().isIn(boolean),
    check('device_token').exists().not().isEmpty(),
    check('contact_disturbance_time').exists().isIn(Object.keys(donor_contact_disturbance_time)),
    body('contact_disturbance_instructions')
    .if((value, { req }) => req.body.contact_disturbance_time)
    .if(body('contact_disturbance_time').exists())
    .custom((value, { req }) => req.body.contact_disturbance_time != '4')
],
    donorsController.create
);

module.exports.handler = serverless(app);