/**
 * Route: GET /states
 */

const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });
const util = require('./util.js');
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const params = {
        TableName: 'states',
        ScanIndexForward: true
    };

    try {
        const statesData = await dynamodb.scan(params).promise();

        return {
            statusCode: 200,
            headers: util.getResponseHeaders(),
            body: JSON.stringify(statesData)
        };
    } catch (err) {
        console.log("Error", err);
        return {
            statusCode: err.statusCode ? err.statusCode : 500,
            headers: util.getResponseHeaders(),
            body: JSON.stringify({
                error: err.name ? err.name : "Exception",
                message: err.message ? err.message : "Unknown error"
            })
        };
    }
}