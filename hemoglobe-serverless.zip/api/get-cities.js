/**
 * Route: GET /cities
 */

const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });
const util = require('./util.js');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const tableName = 'cities';

exports.handler = async (event) => {

    try {
        let state_id = decodeURIComponent(event.pathParameters.state_id);

        let params = {
            TableName: tableName,
            // IndexName: "id-index",
            FilterExpression: "state_id = :state_id",
            ExpressionAttributeValues: {
                ":state_id": Number(state_id)
            },
        };

        let data = await dynamodb.scan(params).promise();
        if(data.Items) {
            return {
                statusCode: 200,
                headers: util.getResponseHeaders(),
                body: JSON.stringify(data)
            };
        } else {
            return {
                statusCode: 404,
                headers: util.getResponseHeaders()
            };
        }      
    } catch (err) {
        return {
            statusCode: err.statusCode ? err.statusCode : 500,
            headers: util.getResponseHeaders(),
            body: JSON.stringify({
                error: err.name ? err.name : "Exception",
                message: err.message ? err.message : "Unknown error"
            })
        };
    }
}