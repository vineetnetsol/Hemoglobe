const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });
const dynamodb = new AWS.DynamoDB.DocumentClient();

const getResponseHeaders = () => {
  return {
      'Access-Control-Allow-Origin': '*'
  }
}

exports.handler = async (event) => {
    const params = {
        TableName: 'cms_pages',
    };

    try {
        const statesData = await dynamodb.scan(params).promise();

        return {
            statusCode: 200,
            headers: getResponseHeaders(),
            body: statesData
        };
    } catch (err) {
        console.log("Error", err);
        return {
            statusCode: err.statusCode ? err.statusCode : 500,
            headers: getResponseHeaders(),
            body: JSON.stringify({
                error: err.name ? err.name : "Exception",
                message: err.message ? err.message : "Unknown error"
            })
        };
    }
}
