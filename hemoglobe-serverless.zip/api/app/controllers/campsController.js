const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");
const {response_status} = require('../config/params');
const { validationResult } = require('express-validator');
const donorsModel = require('../models/donors');
const eventsRegistrationModel = require('../models/eventsRegistrationModel');

const dbClient = new DynamoDBClient();

module.exports.listCamp = async(req, res) => {
    let status = 200;
    let message = "Camps found";
    let eventlisting = [];

    //Add data to the events table
    const input = {
        TableName: 'events',
    }
    const queryReq = req.query;
    checkbyName = queryReq.name == undefined ? '' : queryReq.name;
    
    try {
        const events = await dbClient.send(new ScanCommand(input));
        if (events.Items) {
            events.Items.reverse();
            events.Items.forEach(function (item) {
                if ((checkbyName != '' && (item.name.includes(checkbyName) || item.blood_center.includes(checkbyName) || item.address.includes(checkbyName) || item.city.includes(checkbyName) || item.state.includes(checkbyName))) || checkbyName == '') {
                    eventlisting.push({
                        id: item.id,
                        event_name: item.name,
                        blood_center: item.blood_center,
                        address: item.address,
                        city: item.city,
                        state: item.state,
                        organized_date: item.organized_date,
                        organized_time: item.organized_time,
                        phone: item.phone,
                        email: item.email
                    });
                }
            });
        } 
        if (!eventlisting.length) {
            message = "No camps found. Please try later";
            status = 400;
        }
    } catch (err) {
        console.log("Error", err.stack);
    }
    res.status(status).json({ status, message: message, events: eventlisting });
}

module.exports.createCamp = async(req, res) => {
    let randomNum = 1300000000000;
    let status = 200;
    let message = "Camp has been added successfully!";
    let errors = [];

    //Add data to the events table
    const event = {
        TableName: 'events', 
        Item: {
            id: {'S': (new Date().getTime() - randomNum).toString()},
            name: {'S': req.body.name},
            blood_center: {'S': req.body.blood_center},
            address: {'S': req.body.address},
            city: {'S': req.body.city},
            state: {'S': req.body.state},
            phone: {'S': req.body.phone},
            email: {'S': req.body.email},
            created: {'S': (new Date().getTime()).toString()},
            organized_date: {'S': req.body.organized_date},
            organized_time: {'S': req.body.organized_time},
            organizer_id: {'N': `${req.body.organizer_id}`},
        }
    }
    
    try {
        validationResult(req).throw();
        const result = await dbClient.send(new PutItemCommand(event));
    } catch (err) {
        status = 400;
        message = "Unable to add camp, please try later!";
        console.log("Error", err.stack);
        errors = validationResult(req).mapped();
    }
    res.status(status).json({ status, message: message, errors: errors });
}

//Register event
module.exports.register = async(req, res) => {

    let status = response_status.FAIL;
    let message = '';

    try {

        validationResult(req).throw();
        const bodyData = req.body;
        const ifUser = await donorsModel.validateById(bodyData.uid);
        if(ifUser == false){
            res.json({status, errors: ["User doesn't exists."], message: "User doesn't exists."});
        }

        const ifAlreadyRegistered = await eventsRegistrationModel.validateIfRegistered(bodyData.uid, bodyData.event_id);
        if(ifAlreadyRegistered == true){
            res.json({status, errors: ["User has already registered for the event."], message: "You have already registered for the event."});
        }

        const {status, error, message} = await eventsRegistrationModel.create(bodyData);
        res.json({status, message, errors: error});

    } catch (err) {
        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.array() });
    }
}

//Update registration status
module.exports.updateRegistration = async(req, res) => {
 
    let status = response_status.FAIL;
    let message = '', errors = [];

    try {
        validationResult(req).throw();
        const eventRegId = req.params.id;
        const statusVal = req.body.status;
        const ifExists = await eventsRegistrationModel.validateIfRegistered(eventRegId);
        if(ifExists == false){
            res.json({status, errors: ["Camp registration not found."], message: "Camp registration not found."});
        }

        const ifUpdated = await eventsRegistrationModel.updateStatus(eventRegId, statusVal);

        if(ifUpdated){
            status = response_status.SUCCESS;
            message = "Your request has been updated successfully.";
        }else{
            message = "Unable to process your request.";
        }

        res.json({status, message, errors: error});

    } catch (err) {
        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.array() });
    }    
}