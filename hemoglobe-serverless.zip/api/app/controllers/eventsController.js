const {response_status} = require('../config/params');
const { validationResult } = require('express-validator');
const donorsModel = require('../models/donors');
const eventsRegistrationModel = require('../models/eventsRegistrationModel');

//Register event
module.exports.register = async(req, res) => {

    let status = response_status.FAIL;
    let message = '';

    try {
        validationResult(req).throw();
        const bodyData = req.body;
        const ifUser = await donorsModel.validateById(bodyData.uid);

        if(ifUser == false){
            res.json({status, errors: ["User doesn't exists"], message: "User doesn't exists"});
        }else{
            const ifAlreadyRegistered = await eventsRegistrationModel.validateIfRegistered(bodyData.uid, bodyData.event_id);
            if(ifAlreadyRegistered == true){
                res.json({status, errors: ["User has already registered for this event."], message: "You have already registered for the event."});
            }else{
                const {status, error, message} = await eventsRegistrationModel.create(bodyData);
                res.json({status, message, errors: error});
            }
        }

    } catch (err) {
        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.array() });
    }
}

//Update registration status
module.exports.updateRegistration = async(req, res) => {
 
    let status = response_status.FAIL;
    let message = '', errors = [];

    try {
        validationResult(req).throw();
        const eventRegId = req.params.id;
        const statusVal = req.body.status;
        const ifExists = await eventsRegistrationModel.validateIfRegistered(eventRegId);
        if(ifExists == false){
            res.json({status, errors: ["Event registration not found"], message: "Event registration not found"});
        }

        const ifUpdated = await eventsRegistrationModel.updateStatus(eventRegId, statusVal);

        if(ifUpdated){
            status = response_status.SUCCESS;
            message = "Your request has been updated successfully.";
        }else{
            message = "Unable to update the request.";
        }

        res.json({status, message, errors: error});

    } catch (err) {
        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.array() });
    }    
}