const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { validationResult } = require('express-validator');
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");
const { createHash } = require('crypto');
const util = require('../../util.js');

const dbClient = new DynamoDBClient();
module.exports.login = async(req, res) => {
    let status = 200;
    let message = "Success";
    let errors = [];

    // Check user credentials
    try {
        validationResult(req).throw();

        const passwordHash = createHash('sha256').update(req.body.password).digest('hex');

        const input = {
            TableName: "organizations",
            FilterExpression: "email = :email AND password = :password",
                ExpressionAttributeValues: {
                    ":email": req.body.email,
                    ":password": passwordHash
                }
        }

        const result = await dbClient.send(new ScanCommand(input));
        console.log("result : ", result);
        let organizer = [];
        if(!result.Count) {
            status = 400;
            message = "Invalid login details.";
        } else {
            organizer.push({
                'id': result.Items[0]['id'],
                'name': result.Items[0]['name'],
                'email': result.Items[0]['email'],
                'phone': result.Items[0]['phone'],
                'website': result.Items[0]['website'],
                'address': result.Items[0]['address'],
                'city': result.Items[0]['city'],
                'area_served': result.Items[0]['area']
            });
        }

        res.status(status).json({ status:status, message: message, data: organizer });
        
    } catch (err) {
        status = 400;
        message = "Credentials not matched.";
        console.log("Error", err.stack);
        errors = validationResult(req).mapped();

        res.status(status).json({ status:status, message: message, errors: errors });
    }

}