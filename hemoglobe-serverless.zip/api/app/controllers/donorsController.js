const donorsModel = require('../models/donors');
const {response_status} = require('../config/params');
const { validationResult } = require('express-validator');
const eventsRegistrationModel = require('../models/eventsRegistrationModel');

//Register donor
module.exports.create = async(req, res) => {

    let status = response_status.FAIL;
    let message = '', data = {};

    try {
        validationResult(req).throw();
        const bodyData = req.body;
        const eventId = bodyData.event_id == undefined ? null : bodyData.event_id;
        const {status, error, message, data} = await donorsModel.create(bodyData);

        if(status && eventId != null){
            const newData = {uid: data.insert_id, event_id: eventId};
            await eventsRegistrationModel.create(newData);
        }

        res.json({status, message, errors: error});

    } catch (err) {

        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.mapped() });
    }
}

module.exports.searchByEmail = async(req, res) => {
 
    let status = response_status.FAIL;
    let message = '', data = {}, error = [];

    try {
        validationResult(req).throw();
        const bodyData = req.body;
        const donorObj = await donorsModel.searchByEmail(bodyData.email);

        if(donorObj){
            const newData = {uid: donorObj.id, event_id: bodyData.event_id};
            eventsRegistrationModel.create(newData);
            status = response_status.SUCCESS;
            message = "Your email is already registered with us.";
        }else{
            message = "Your email is not registered with us.";
        }
        res.json({status, message, errors: error});
        
    } catch (err) {
        message = 'We are unable to process your request.Please try after some time.';
        const errors = validationResult(req);
        res.status(400).json({ status, message, errors: errors.mapped() });
    }
}