const {response_status} = require('../config/params');
const donorsModel = require('../models/donors');
const eventsModel = require('../models/events');

module.exports.searchBloodAvailability = async(req, res) => {
    let status = response_status.FAIL;
    let message = '', data = {};

    try{
        status = response_status.SUCCESS;
        const bodyReq = req.body;
        const cityName = bodyReq.city == undefined ? '' : bodyReq.city.trim();
        const bloodGrp = bodyReq.blood_group == undefined ? '' : bodyReq.blood_group.trim();
        data.donors = await donorsModel.getDonorsByCity(cityName, bloodGrp);
        data.events = await eventsModel.getEventsByCity(cityName);
    }
    catch(err){
        message = "We are unable to process your request.Please try after some time.";
    }
    res.json({status, message, data});
}