module.exports.response_status = {
    'FAIL': false,
    'SUCCESS': true
}

module.exports.gender = {
    'm': 'Male',
    'f': 'Female',
    'o': 'Others'
}

module.exports.blood_type = ['A+', 'O+', 'B+', 'AB+', 'A-', 'O-', 'B-', 'AB-'];

module.exports.boolean = {1: true, 0: false};

module.exports.donor_contact_mode = {
    'm': 'Mobile', 
    'h': 'Home Phone',
    'e': 'Email',
    's': 'SMS'
}

module.exports.donor_contact_disturbance_time = {
    0: 'At Night',
    1: 'During Official Hours',
    2: 'Manual Timings',
    3: 'Preferred Occasion',
    4: 'Other Instructions (if any)'
}