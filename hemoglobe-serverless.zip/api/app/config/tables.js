module.exports = {
    donors: 'donors',
    cities: 'cities',
    organizations: 'organizations',
    events: 'events',
    events_registrations: 'events_registrations',
    blood_groups: 'blood_groups'
}