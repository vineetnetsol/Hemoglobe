
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");

const tables = require('../config/tables');
const TABLE = tables.events;

const eventsRegistrationModel = require('./eventsRegistrationModel');

const dbClient = new DynamoDBClient();


/**
 * @param {*} 'name': city name to be searched 
 * @returns 
 */
module.exports.getEventsByCity = async(city_name) => {

    const input = {
        TableName: TABLE
    }

    if(city_name){
        input.FilterExpression = 'city = :city';
        input.ExpressionAttributeValues = {':city': city_name}
    }

    try {
    
        const result = await dbClient.send(new ScanCommand(input));
        let items = result.Items;
        for(let i in items){
            items[i].count = await eventsRegistrationModel.countActiveStatus(items[i].id);
        }
    
        return Promise.all(items);
    
    } catch (error) {
    
        return [];
    
    }

}