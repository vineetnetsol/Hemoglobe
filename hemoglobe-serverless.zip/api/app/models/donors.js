const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");
const tables = require('../config/tables');
const util = require('../../util.js');
const dbClient = new DynamoDBClient();
const TABLE = tables.donors;

// Register a new Blood Donor
module.exports.create = async(data) => {

    let status = false;
    let error = [];
    let message = '';

    if(await validateEmailExists(data.email)){
        message = 'This email is already registered with us.';
        error.push(message);
        return {
            status, error, message
        }
    }

    const uCurrentStamp = Date.now();
    const currentStamp = (uCurrentStamp/1000).toFixed(0);

    //Add data
    const input = {
        TableName: TABLE, 
        Item: {
            email: {'S': data.email},
            name: {'S': data.name},
            //TODO Inc auto id
            id: {'S': `HG${uCurrentStamp}`},
            created: {'N': `${currentStamp}`},
            gender: {'S': data.gender},
            dob: {'S': data.dob},
            blood_group: {'S': data.blood_group},
            disease: {'BOOL': Boolean(Number(data.disease)) },
            city: {'S': data.city},
            state: {'S': data.state},
            phone: {'S': data.phone},
            address: {'S': data.address},
            //TODO: hash password
            //password: {'S': data.password},
            contact_mode: {'SS': data.contact_mode},
            device_token: {'S': data.device_token},
            contact_directly: {'BOOL': Boolean( Number(data.contact_directly) )},
            contact_disturbance_time: {'N': `${data.contact_disturbance_time}`}
        }
    }

    if(data.contact_disturbance_instructions != undefined){
        input.Item.contact_disturbance_instructions = {'S': data.contact_disturbance_instructions}
    }
    
    try {
        const result = await dbClient.send(new PutItemCommand(input)); 
        status = Boolean(result);
        if(result){
            data.insert_id = `HG${uCurrentStamp}`;
            message = 'Your account has been created successfully.';
        }else{
            message = 'Unable to create account.Please try later.';
        }
    
    } catch (err) {
     
        status = false;
        error.push(err.stack);
        message = 'We are unable to process your request.Please try after some time.';
    
    } finally{
        return {
            status, error, message, data
        }
    }
}

async function validateEmailExists(email) {

    const input = {
        TableName: TABLE,
        FilterExpression: "email = :email",
        ExpressionAttributeValues: {
            ":email": email
        }
    }

    try {
        const result = await dbClient.send(new ScanCommand(input));
        return Boolean(result.Count);
    } catch (error) {
        return false;
    }
}

module.exports.getDonorsByCity = async(city_name, blood_group) => {

    const input = {
        TableName: TABLE
    }

    //Array to hold bloor groups for filtration
    const bloodGroupsArr = [];
    if(blood_group){
    
        bloodGroupsArr.push({val: blood_group, is_matching: true});
        const compatibleGrps = await getCompatibleBloodGroups(blood_group);
        compatibleGrps.forEach(function(val){
            bloodGroupsArr.push({val: val, is_matching: false});
        });
    
        var titleObject = {};
        var index = 0;
        bloodGroupsArr.forEach(function(value) {
            index++;
            var titleKey = ":titlevalue"+index;
            titleObject[titleKey.toString()] = value.val;
        });
    }

    if(city_name && !blood_group){
        input.FilterExpression = 'city = :city';
        input.ExpressionAttributeValues = {':city': city_name}
    }
    else if(!city_name && blood_group){
        input.FilterExpression = 'blood_group IN ('+Object.keys(titleObject).toString()+')';
        input.ExpressionAttributeValues = titleObject
    }
    else if(city_name && blood_group){
        //input.FilterExpression = 'city = :city AND blood_group IN (:blood_group)';
        //input.ExpressionAttributeValues = {':blood_group': Object.keys(titleObject).toString(), ':city': city_name}
        input.FilterExpression = 'blood_group IN ('+Object.keys(titleObject).toString()+')';
        input.ExpressionAttributeValues = titleObject
    }

    try {
        const result = await dbClient.send(new ScanCommand(input));
        let resultArr = result.Items;
        //Fitler acc to city
        if(city_name){
            resultArr = resultArr.filter(v => v.city == city_name || v.address == city_name || v.state == city_name || v.name == city_name)
        }
        if(blood_group){
            resultArr = resultArr.map( function(v){
                //const bloodGrp = bloodGroupsArr.filter(k => k.val == v.blood_group);
                v.is_matching = v.blood_group == blood_group ? 1 : 0;
                return v;
            } );
        }

        return resultArr;

    } catch (error) {
        return [];
    }
}

/**
 * Check if donor exists by its id (or uid)
 * @param {*} id 
 */
module.exports.validateById = async(id) => {

    const input = {
        TableName: TABLE,
        FilterExpression: 'id = :id',
        ExpressionAttributeValues: {':id': id} 
    }

    try {
        const result = await dbClient.send(new ScanCommand(input));
        return Boolean(result.Count);
    } catch (error) {
        return false;
    }
}

module.exports.searchByEmail = async(email) => {

    const input = {
        TableName: TABLE,
        FilterExpression: "email = :email",
        ExpressionAttributeValues: {
            ":email": email
        }
    }

    try {
        const result = await dbClient.send(new ScanCommand(input));
        return result.Items[0];
    } catch (error) {
        return null;
    }
}

async function getCompatibleBloodGroups(blood_group) {

    const inputX = {
        TableName: tables.blood_groups,
        FilterExpression: "bgroup = :bgroup",
        ExpressionAttributeValues: {
            ":bgroup": blood_group
        }
    }
    try{
        const result1 = await dbClient.send(new ScanCommand(inputX));
        return result1.Items.length > 0 ? result1.Items[0].recieved_from : [];
    }
    catch(err){
        return [];
    }
}