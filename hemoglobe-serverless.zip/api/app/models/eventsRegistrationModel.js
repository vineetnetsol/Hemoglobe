const { DynamoDBClient, PutItemCommand, QueryCommand } = require("@aws-sdk/client-dynamodb");
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");
const tables = require('../config/tables');
const TABLE = tables.events_registrations;
const dbClient = new DynamoDBClient();

module.exports.create = async(data) => {

    let status = false;
    let error = [];
    let message = '';

    const uCurrentStamp = Date.now();
    const currentStamp = uCurrentStamp/1000;
    //Add data
    const input = {
        TableName: TABLE, 
        Item: {
            donor_id: {'S': data.uid},
            id: {'S': `HG${uCurrentStamp}`},
            created: {'N': `${currentStamp}`},
            event_id: {'N': `${data.event_id}`},
            xyz: {'N': '0'}
        }
    }
   
    try {
        const result = await dbClient.send(new PutItemCommand(input)); 
        status = Boolean(result);
        message = status ? 'You have been registered successfully.': 'Unable to register,please try later.';
    } catch (err) {
        status = false;
        error.push(err.stack);
        message = 'We are unable to process your request.Please try after some time.';
    } finally{
        return {
            status, error, message
        }
    }
}

module.exports.validateIfRegistered = async(uid, event_id) => {

    const input = {
        TableName: TABLE,
        FilterExpression: "donor_id = :uid AND event_id = :event_id",
        ExpressionAttributeValues: {
            ":uid": uid,
            ":event_id": event_id
        }
    }

    try {
        const result = await dbClient.send(new ScanCommand(input));
        return Boolean(result.Count);
    } catch (error) {
        return false;
    }
}

module.exports.updateStatus = async(event_reg_id, status_val) => {

    const input = {
        TableName: TABLE,
        Key: {
            'id': event_reg_id
        },
        UpdateExpression: "set xyz = :xyz",
        ExpressionAttributeValues: {
            ":xyz": status_val
        }
    }

    try {
        const result = await dbClient.update(new ScanCommand(input));
        return Boolean(result.Count);
    } catch (error) {
        return false;
    }
}

module.exports.countActiveStatus = async(event_id) => {
    try{
        const input = {
            TableName: TABLE,
            FilterExpression: "event_id = :event_id AND xyz = :xyz",
            ExpressionAttributeValues: {
                ":xyz": 1,
                ":event_id": Number(event_id)
            }
        }

        const countActiveRes = await dbClient.send(new ScanCommand(input));
        return countActiveRes.Count;
    }catch(err){
        return 0;
    }
}