const serverless = require('serverless-http');
const express = require('express')
const app = express();
const bodyParser = require('body-parser');
const { check } = require('express-validator');
const donorsController = require('./app/controllers/donorsController');

//Parse application/json
app.use(bodyParser.json());

//Check if email is already registered
app.post('/donors/check-email', [
    check('email').exists().isEmail(),
    check('event_id').exists().not().isEmpty()
], donorsController.searchByEmail);

module.exports.handler = serverless(app);