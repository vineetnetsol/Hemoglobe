const serverless = require('serverless-http');
const express = require('express');
const app = express();
const bodyParser = require("body-parser");

const campsController = require('./app/controllers/campsController');
const { check } = require('express-validator');

app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/add-camp', [
    check('name').exists().not().isEmpty(),
    check('blood_center').exists().not().isEmpty(),
    check('address').exists().not().isEmpty(),
    check('city').exists().not().isEmpty(),
    check('state').exists().not().isEmpty(),
    check('phone').exists().not().isEmpty(),
    check('email').exists().isEmail().not().isEmpty(),
    check('organized_date').exists().not().isEmpty(),
    check('organized_time').exists().not().isEmpty(),
    check('organizer_id').exists().not().isEmpty()
], campsController.createCamp);

module.exports.handler = serverless(app);