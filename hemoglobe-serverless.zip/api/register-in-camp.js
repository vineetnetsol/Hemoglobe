// 'use strict';
const serverless = require('serverless-http');
const express = require('express')
const app = express();
const bodyParser = require('body-parser');
const { check } = require('express-validator');
const eventsController = require('./app/controllers/eventsController');

//Parse application/json
app.use(bodyParser.json());

//Create (register) donor
    //Event Register (donor)
    app.post('/camp/donor-register', [
        check('uid').exists().not().isEmpty(),
        check('event_id').exists().not().isEmpty().isInt({min: 1})
    ], eventsController.register);

module.exports.handler = serverless(app);