const serverless = require('serverless-http');
const express = require('express')
const app = express();
const bodyParser = require('body-parser');
const basicController = require('./app/controllers/basicController');

//Parse application/json
app.use(bodyParser.json());

app.post('/search/donor', basicController.searchBloodAvailability);
module.exports.handler = serverless(app);