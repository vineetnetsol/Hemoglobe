const serverless = require('serverless-http');
const express = require('express');
const app = express();
const bodyParser = require("body-parser");

const campsController = require('./app/controllers/campsController');
const { check } = require('express-validator');

app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/list-camps', campsController.listCamp);

module.exports.handler = serverless(app);